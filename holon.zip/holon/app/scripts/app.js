define([], function() {
  return 'Hello from Yeoman!';
});